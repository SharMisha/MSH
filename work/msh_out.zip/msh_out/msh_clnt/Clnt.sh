./mshclnt byxUsrUI
